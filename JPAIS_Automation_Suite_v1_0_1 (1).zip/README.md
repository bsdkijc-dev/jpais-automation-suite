# JPAIS Automation Suite v1.0

This package is a bound Google Apps Script suite for the full JPAIS Project Management Google Sheet.

## Scope completed in v1.0

- Validates the JPAIS workbook structure.
- Adds a `JPAIS` menu to Google Sheets.
- Uses the configured JPAIS root Drive folder.
- Creates or reuses the standard Drive hierarchy.
- Creates a complete Knowledge Package for the selected Production Board row.
- Automatically generates:
  - Executive Summary Google Doc
  - Presentation Google Slides
  - FAQ Google Doc
  - Quiz Google Form
  - Metadata Google Sheet
  - References Google Doc
- Creates folders for:
  - Original Document
  - Audio Overview
  - Mind Map
  - Infographic
- Updates:
  - Production Board
  - Document Registry
  - AI Resource Tracker
  - Google Sites Publisher register
- Prevents duplicate package creation by reusing folders and asking before reusing an existing package.

## Installation

1. Open the full JPAIS Project Management Google Sheet.
2. Select **Extensions → Apps Script**.
3. Delete the default `Code.gs`, or leave it empty.
4. Create the following files:
   - `Config.gs`
   - `Menu.gs`
   - `DriveManager.gs`
   - `PackageGenerator.gs`
   - `Tracker.gs`
   - `Validation.gs`
   - `Utils.gs`
5. Copy the contents of each file from this package into the matching Apps Script file.
6. Save the project.
7. In Apps Script, select `initializeJPAIS` and click **Run**.
8. Approve the requested Google permissions.
9. Return to the spreadsheet and refresh the browser.
10. The **JPAIS** menu will appear.

## First operational test

1. Open the `Production Board` sheet.
2. Select a populated row starting at row 5.
3. Confirm that these fields contain values:
   - Document ID
   - Document Title
   - Category
   - Assigned Lead
4. Select **JPAIS → Validate Active Row**.
5. Then select **JPAIS → Create Complete Knowledge Package**.
6. Review the result dialog and generated Drive assets.

## Important limitations

Google Sites does not provide an Apps Script service for directly creating or publishing pages in the current Google Sites product. The suite therefore prepares and records all publication links in the `Google Sites Publisher` sheet. A team member then creates the Google Sites page and pastes the prepared links.

NotebookLM also does not provide a standard Apps Script service for automatically creating notebooks or Studio outputs. NotebookLM URLs and outputs are tracked in the workbook and stored in the generated folders.
