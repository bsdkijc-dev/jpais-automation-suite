# JPAIS Automation Suite v1.0.1

Add: StatusEngine.gs
Replace: Menu.gs, PackageGenerator.gs, Utils.gs

Test:
1. Refresh Google Sheet.
2. Select a new Production Board row.
3. Create Complete Knowledge Package.
4. Verify STATUS.json exists in the package root.
5. Use JPAIS > Update Resource Status.
